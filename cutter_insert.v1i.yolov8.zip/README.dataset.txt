# cutter_insert > 2024-05-17 1:23pm
https://universe.roboflow.com/raviteja-pxvqq/cutter_insert

Provided by a Roboflow user
License: CC BY 4.0

